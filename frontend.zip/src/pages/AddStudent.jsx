import React from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
// import { Modal } from "@mui/material";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
function AddStudent() {
  const navigate = useNavigate();
  const [payload, setPayload] = React.useState({});
  const handleSubmit = async () => {
    const student = await axios.post(
      "http://localhost:8000/create-student",
      payload
    );
    if (student.data.success) {
      navigate("/students");
      toast.success("Student created successfully");
    } else {
      toast.error("Error adding student");
    }
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setPayload({ ...payload, [name]: value });
  };
  return (
    <div>
 
      <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      />
      <div className="mask d-flex align-items-center h-auto gradient-custom-3">
        <div className="container h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-12 col-md-9 col-lg-7 col-xl-6">
              <div className="card" style={{ borderRadius: "15px" }}>
                <div className="card-body p-2">
                  <h2 className="text-uppercase text-center mb-5">
                    Create an Student
                  </h2>

                  <form>
                    <div data-mdb-input-init className="form-outline mb-2">
                      <label className="form-label" for="form3Example1cg">
                        Your Name
                      </label>
                      <input
                        onChange={handleChange}
                        name="name"
                        type="text"
                        id="form3Example1cg"
                        className="form-control form-control-sm"
                      />
                    </div>

                    <div data-mdb-input-init className="form-outline mb-2">
                      <label className="form-label" for="form3Example3cg">
                        Your Email
                      </label>
                      <input
                        onChange={handleChange}
                        name="email"
                        type="email"
                        id="form3Example3cg"
                        className="form-control form-control-sm"
                      />
                    </div>

                    <div data-mdb-input-init className="form-outline mb-2">
                      <label className="form-label" for="form3Example4cg">
                        Phone
                      </label>
                      <input
                        onChange={handleChange}
                        name="phone"
                        type="text"
                        id="form3Example4cg"
                        className="form-control form-control-sm"
                      />
                    </div>

                    <div data-mdb-input-init className="form-outline mb-2">
                      <label className="form-label" for="form3Example4cdg">
                        {" "}
                        City{" "}
                      </label>
                      <input
                        type="text"
                        onChange={handleChange}
                        name="city"
                        id="form3Example4cdg"
                        className="form-control form-control-sm"
                      />
                    </div>
                    <div data-mdb-input-init className="form-outline mb-2">
                      <label className="form-label" for="form3Example4cdg">
                        {" "}
                        College{" "}
                      </label>
                      <input
                        type="text"
                        onChange={handleChange}
                        name="college"
                        id="form3Example4cdg"
                        className="form-control form-control-sm"
                      />
                    </div>
                    <div data-mdb-input-init className="form-outline mb-2">
                      <label className="form-label" for="form3Example4cdg">
                        {" "}
                        DOB{" "}
                      </label>
                      <input
                        type="date"
                        onChange={handleChange}
                        name="dob"
                        id="form3Example4cdg"
                        className="form-control form-control-sm"
                      />
                    </div>
                    <div data-mdb-input-init className="form-outline mb-2">
                      <label className="form-label" for="form3Example4cdg">
                        {" "}
                        Status{" "}
                      </label>
                      <select
                        type="text"
                        onChange={handleChange}
                        name="status"
                        id="form3Example4cdg"
                        className="form-control form-control-sm"
                      >
                        <option value={true}> Active</option>
                        <option value={false}>InActive</option>
                      </select>
                    </div>
                    <div data-mdb-input-init className="form-outline mb-2">
                      <label className="form-label" for="form3Example4cdg">
                        {" "}
                        Gender{" "}
                      </label>
                      <select
                        type="text"
                        onChange={handleChange}
                        name="gender"
                        id="form3Example4cdg"
                        className="form-control form-control-sm"
                      >
                        <option value={1}> Male</option>
                        <option value={2}>Female</option>
                      </select>
                    </div>

                    <div className="d-flex justify-content-center">
                      <button
                        type="button"
                        data-mdb-button-init
                        data-mdb-ripple-init
                        className="btn btn-success btn-block btn-md  text-white"
                        onClick={handleSubmit}
                      >
                        Create Student
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddStudent;
