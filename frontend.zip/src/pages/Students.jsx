import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {Modal} from "react-bootstrap";
import { Typography, Button } from "@mui/material";
import { ToastContainer, toast } from "react-toastify";
function Students() {
  const navigate = useNavigate();
  const [students, setStudents] = useState([]);
  const [open, setOpen] = useState(false);
  const [id, setId] = useState("");
  const deleteStudent = async (_id) => {
    const confirmBox = alert("Are you sure you want to delete this student  ");
 
      const deletedSt = await axios.delete(
        "http://localhost:8000/delete-student/" + _id
      );
      if (deletedSt.data.status) {
        toast.success("Student deleted successfully");
      }
    



  };

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get("http://localhost:8000/get-student");
        setStudents(response.data.data);
        console.log("Student ", response.data.data);
      } catch (error) {
        console.log(error);
      }
    };
    fetchUsers();
  }, []);

  return (
    <div>
      <Modal open={open} keepMounted
      
      onClose={()=>{}}
      aria-labelledby="keep-mounted-modal-title"
      aria-describedby="keep-mounted-modal-description"
      >
        <Typography style={{ padding: "10px" }}>
          {" "}
          You want to delete this student?
        </Typography>
        <Button color="primary"  onClick={()=>deleteStudent(id)}>Yes</Button>
        <Button color="error" onClick={()=>setOpen(false)}>No</Button>
      </Modal>
      <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
      />
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

      <div className=" mt-3">
        <h2>Students Table List </h2>
        <p>
          The .table class adds basic styling (light padding and horizontal
          dividers) to a table:
        </p>
        <table className="table">
          <thead>
            <tr>
              <th>Index</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>College</th>
              <th>City</th>
              <th>Status</th>
              <th>Gender</th>
              <th>DOB</th>
              <th>CreatedAt</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {students &&
              students.map((student, index) => {
                return (
                  <tr key={index}>
                    <td> {index + 1} </td>
                    <td>{student.name}</td>
                    <td>{student.email}</td>
                    <td>{student.phone}</td>
                    <td>{student.college}</td>
                    <td>{student.city}</td>
                    <td style={{ color: student.status ? "green" : "red" }}>
                      {" "}
                      {student.status ? "Active" : "InActive"}{" "}
                    </td>
                    <td> {student.gender ? "Male" : "Female"} </td>
                    <td>{student.dob}</td>
                    <td>{student.createdAt.substr(0, 10)}</td>
                    <td>
                      {" "}
                      <div>
                        {" "}
                        <button  onClick={()=>{
                          navigate("/update-student/"+student._id)
                        }} className="btn btn-primary btn-sm outline">
                          Edit
                        </button>{" "}
                        <button
                          onClick={() => {deleteStudent(student._id)}}
                          className="btn btn-danger outline btn-sm"
                        >
                          {" "}
                          Delete
                        </button>{" "}
                      </div>{" "}
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Students;
