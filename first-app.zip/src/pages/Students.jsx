import React, { useEffect, useState } from "react";
import axios from "axios";
function Students() {
  const [students, setStudents] = useState([]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get("http://localhost:8000/get-student");
        setStudents(response.data.data);
        console.log("Student ", response.data.data)
      } catch (error) {
        console.log(error);
      }
    };
    fetchUsers();
  }, []);

  return (
    <div>
      <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
      />
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

      <div class="container mt-3">
        <h2>Students Table List </h2>
        <p>
          The .table class adds basic styling (light padding and horizontal
          dividers) to a table:
        </p>
        <table class="table">
          <thead>
            <tr>
              <th>Index</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>College</th>
              <th>City</th>
              <th>Status</th>
              <th>Gender</th>
              <th>DOB</th>
              <th>CreatedAt</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>John</td>
              <td>Doe</td>
              <td>john@example.com</td>
              <td>John</td>
              <td>Doe</td>
              <td>john@example.com</td>
              <td>john@example.com</td>
              <td>john@example.com</td>
              <td>john@example.com</td>
            </tr>
            <tr>
              <td>1</td>

              <td>Mary</td>
              <td>Moe</td>
              <td>mary@example.com</td>
              <td>Mary</td>
              <td>Moe</td>
              <td>mary@example.com</td>
              <td>mary@example.com</td>
              <td>john@example.com</td>
              <td>john@example.com</td>
            </tr>
            <tr>
              <td>1</td>
              <td>July</td>
              <td>Dooley</td>
              <td>july@example.com</td>
              <td>July</td>
              <td>Dooley</td>
              <td>july@example.com</td>
              <td>july@example.com</td>
              <td>john@example.com</td>
              <td>john@example.com</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Students;
