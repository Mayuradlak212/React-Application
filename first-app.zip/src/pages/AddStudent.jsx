import React from 'react'

function AddStudent() {
  return (
    <div>
         <h1>Add new Student </h1>
    </div>
  )
}

export default AddStudent
