import React from 'react'

function Contact() {
  return (
    <div  style={{height:"30vh",margin:"1rem", width:"auto", backgroundColor:"pink",display:"flex","alignItems":"center",justifyContent:"center"}}>
        <h1>  Contact for For any Doubt </h1>
    </div>
  )
}

export default Contact
