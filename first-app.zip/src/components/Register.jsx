import React, { useEffect, useState } from "react";
import "../style/register.css";
import axios from "axios";
function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [age, setAge] = useState("");
  const [phone, setPhone] = useState("");
  const [data, setData] = useState([]);
  const [isSubmitted, setSubmitted] = useState(false);

  useEffect(() => {
    const getData = async () => {
      const response = await axios.get("http://localhost:8000/get-users");
      setData(response.data);
    };
    getData();
  }, []);

  const handleSubmit = async (e) => {
    // e.preventDefault();
    const payload = {
      name: name,
      email: email,
      phone: phone,
    };
    console.log("Payload: ", payload);
    const response = await axios.post(
      "http://localhost:8000/create-user",
      payload
    );
    console.log("API response: ", response.data);
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  };

  const delteUser = async (id) => {
    const response = await axios.delete(
      `http://localhost:8000/delete-user/${id}`
    );
    console.log("API response: ", response.data);
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  };
  console.log("Register ");
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",

        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          boxShadow: "2px 2px 2px 2px",
          height: "50vh",
          width: "30vw",
          padding: "10px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          marginBottom: "30px",
          // justifyContent: "center",
        }}
      >
        <h3>Student Regitration Form</h3>

        <label htmlFor=""> Enter Your name </label>
        <input
          onChange={(e) => setName(e.target.value)}
          style={{
            width: "200px",
            padding: "8px",
            border: "1px solid black",
            borderRadius: "4px",
          }}
          type="text"
        />

        <label style={{ fontSize: "18px", padding: "10px" }} htmlFor="">
          Enter Your Email
        </label>
        <input
          onChange={(e) => setEmail(e.target.value)}
          style={{
            width: "200px",
            padding: "8px",
            border: "1px solid black",
            borderRadius: "4px",
          }}
          type="email"
        />

        <label style={{ fontSize: "18px", padding: "10px" }} htmlFor="">
          Enter Your Phone
        </label>
        <input
          onChange={(e) => setPhone(e.target.value)}
          style={{
            width: "200px",
            padding: "8px",
            border: "1px solid black",
            borderRadius: "4px",
          }}
          type="number"
        />

        <button
          onClick={handleSubmit}
          style={{
            fontSize: "15",
            margin: "10px",
            backgroundColor: "green",
            color: "white",
            cursor: "pointer",
            width: "100px",
            padding: "8px",
          }}
        >
          Submit
        </button>
      </div>

      <div style={{ width: "60vw" }}>
        <table border={1}>
          <thead>
            <tr style={{ padding: "10px" }}>
              <th>Index</th>
              <th>Enroll Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr key={index}>
                <td style={{ padding: "10px" }}>{index + 1}</td>
                <td style={{ padding: "10px" }}>{item._id.toUpperCase()}</td>
                <td style={{ padding: "10px" }}>{item.name}</td>
                <td style={{ padding: "10px" }}>{item.email}</td>
                <td style={{ padding: "10px" }}>{item.phone}</td>
                <td style={{ padding: "10px" }}>
                  <button
                    onClick={() => delteUser(item._id)}
                    style={{
                      backgroundColor: "red",
                      color: "white",
                      cursor: "pointer",
                    }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Register;
